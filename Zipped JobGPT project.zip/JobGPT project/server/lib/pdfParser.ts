// Simple text extraction for PDF files
// In a production environment, you would use a more robust PDF parsing library

export async function extractTextFromPDF(buffer: Buffer): Promise<string> {
  // This is a simplified implementation
  // In production, use libraries like pdf-parse, pdf2pic, or pdfjs-dist
  
  try {
    // Convert buffer to string and extract basic text
    const text = buffer.toString('utf8');
    
    // Basic text cleaning and extraction
    let extractedText = text
      .replace(/[^\x20-\x7E\n]/g, '') // Remove non-printable characters
      .replace(/\s+/g, ' ') // Normalize whitespace
      .trim();
    
    // If the extracted text is too short, it might be a binary PDF
    if (extractedText.length < 100) {
      // Fallback: extract readable strings from binary data
      const matches = buffer.toString('binary').match(/[\x20-\x7E]{4,}/g);
      if (matches) {
        extractedText = matches.join(' ').replace(/\s+/g, ' ').trim();
      }
    }
    
    return extractedText;
  } catch (error) {
    console.error('Error extracting text from PDF:', error);
    throw new Error('Failed to extract text from PDF file');
  }
}

export async function extractTextFromFile(buffer: Buffer, mimeType: string): Promise<string> {
  if (mimeType === 'application/pdf') {
    return extractTextFromPDF(buffer);
  } else if (mimeType.includes('text/') || mimeType.includes('application/msword')) {
    // Handle plain text and basic Word documents
    return buffer.toString('utf8').replace(/[^\x20-\x7E\n]/g, '').trim();
  } else {
    throw new Error('Unsupported file type');
  }
}
