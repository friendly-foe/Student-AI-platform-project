import { useQuery } from "@tanstack/react-query";
import { BarChart3, CheckCircle, AlertTriangle, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

export default function ResumeAnalysis() {
  const { data: resumeData, isLoading, isError } = useQuery({
    queryKey: ["/api/resume/analysis"],
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-48" />
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-20 w-full" />
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isError || !resumeData) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center">
            <AlertTriangle className="w-12 h-12 text-warning mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No Resume Analysis Found</h3>
            <p className="text-gray-600">Upload a resume to get started with AI-powered analysis.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const { analysis, resume } = resumeData;

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-success";
    if (score >= 60) return "text-warning";
    return "text-destructive";
  };

  const getCompatibilityBadge = (compatibility: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive"> = {
      "Excellent": "default",
      "Good": "secondary",
      "Fair": "secondary",
      "Poor": "destructive",
    };
    return variants[compatibility] || "secondary";
  };

  return (
    <div className="space-y-6">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Resume Analysis</h2>
        <p className="text-gray-600">Detailed AI-powered analysis of your resume with actionable insights.</p>
      </div>

      {/* Overview Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <BarChart3 className="mr-2" size={20} />
            Overall Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className={`text-4xl font-bold ${getScoreColor(analysis.overallScore)} mb-2`}>
                {analysis.overallScore}/100
              </div>
              <p className="text-sm text-gray-600">Overall Score</p>
              <Progress value={analysis.overallScore} className="mt-2" />
            </div>
            
            <div className="text-center">
              <Badge variant={getCompatibilityBadge(analysis.atsCompatibility)} className="mb-2">
                {analysis.atsCompatibility}
              </Badge>
              <p className="text-sm text-gray-600">ATS Compatibility</p>
            </div>
            
            <div className="text-center">
              <Badge variant={getCompatibilityBadge(analysis.keywordOptimization)} className="mb-2">
                {analysis.keywordOptimization}
              </Badge>
              <p className="text-sm text-gray-600">Keyword Optimization</p>
            </div>
          </div>

          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">Resume: {resume.filename}</span>
              <span className="text-xs text-gray-500">
                Analyzed {new Date(resume.uploadedAt).toLocaleDateString()}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Strengths and Weaknesses */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-success">
              <CheckCircle className="mr-2" size={20} />
              Strengths
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {analysis.strengths.map((strength: string, index: number) => (
                <li key={index} className="flex items-start">
                  <div className="w-2 h-2 bg-success rounded-full mt-2 mr-3 flex-shrink-0" />
                  <span className="text-sm text-gray-700">{strength}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-warning">
              <AlertTriangle className="mr-2" size={20} />
              Areas for Improvement
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {analysis.weaknesses.map((weakness: string, index: number) => (
                <li key={index} className="flex items-start">
                  <div className="w-2 h-2 bg-warning rounded-full mt-2 mr-3 flex-shrink-0" />
                  <span className="text-sm text-gray-700">{weakness}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* Improvement Suggestions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <TrendingUp className="mr-2" size={20} />
            Actionable Improvements
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {analysis.improvements.map((improvement: string, index: number) => (
              <div key={index} className="p-4 bg-primary/5 rounded-lg border border-primary/10">
                <p className="text-sm text-gray-700 mb-2">{improvement}</p>
                <div className="flex items-center text-primary text-xs">
                  <TrendingUp size={12} className="mr-1" />
                  Priority: High
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Skills Identified */}
      <Card>
        <CardHeader>
          <CardTitle>Skills Identified</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {analysis.skillsIdentified.map((skill: any, index: number) => (
              <div key={index} className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-gray-900">{skill.name}</span>
                  <Badge variant="outline">{skill.category}</Badge>
                </div>
                <div className="flex items-center">
                  <Progress value={skill.level} className="flex-1 mr-2" />
                  <span className="text-sm text-gray-600">{skill.level}%</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
