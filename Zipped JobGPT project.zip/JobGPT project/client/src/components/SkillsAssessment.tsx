import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, TrendingUp, Award } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest } from "@/lib/queryClient";

export default function SkillsAssessment() {
  const queryClient = useQueryClient();

  const { data: skills = [], isLoading } = useQuery({
    queryKey: ["/api/skills"],
  });

  const updateSkillMutation = useMutation({
    mutationFn: async ({ id, level }: { id: number; level: number }) => {
      const response = await apiRequest("PATCH", `/api/skills/${id}`, { level });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/skills"] });
    },
  });

  const getSkillLevel = (level: number) => {
    if (level >= 90) return { label: "Expert", color: "text-success" };
    if (level >= 70) return { label: "Advanced", color: "text-primary" };
    if (level >= 50) return { label: "Intermediate", color: "text-warning" };
    return { label: "Beginner", color: "text-destructive" };
  };

  const getProgressColor = (level: number) => {
    if (level >= 90) return "bg-success";
    if (level >= 70) return "bg-primary";
    if (level >= 50) return "bg-warning";
    return "bg-destructive";
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-32" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="space-y-2">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-2 w-full" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            <Award className="mr-2" size={20} />
            Skills Assessment
          </CardTitle>
          <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80">
            <Plus className="mr-1" size={16} />
            Add Skill
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {skills.length === 0 ? (
          <div className="text-center py-8">
            <Award className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No Skills Identified</h3>
            <p className="text-gray-600 text-sm mb-4">Upload a resume to automatically identify your skills.</p>
            <Button size="sm">Upload Resume</Button>
          </div>
        ) : (
          <div className="space-y-4">
            {skills.map((skill: any) => {
              const skillLevel = getSkillLevel(skill.level);
              return (
                <div key={skill.id} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-gray-700">{skill.name}</span>
                      <Badge variant="outline" className="text-xs">
                        {skill.category}
                      </Badge>
                    </div>
                    <span className={`text-xs ${skillLevel.color}`}>
                      {skillLevel.label}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Progress 
                      value={skill.level} 
                      className="flex-1"
                    />
                    <span className="text-sm text-gray-600 min-w-[3rem] text-right">
                      {skill.level}%
                    </span>
                  </div>
                  
                  {/* Quick action buttons for skill level adjustment */}
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 px-2 text-xs"
                      onClick={() => updateSkillMutation.mutate({ 
                        id: skill.id, 
                        level: Math.max(0, skill.level - 10) 
                      })}
                      disabled={updateSkillMutation.isPending}
                    >
                      -10
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 px-2 text-xs"
                      onClick={() => updateSkillMutation.mutate({ 
                        id: skill.id, 
                        level: Math.min(100, skill.level + 10) 
                      })}
                      disabled={updateSkillMutation.isPending}
                    >
                      +10
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <Button className="w-full mt-4 bg-primary hover:bg-primary/90" size="sm">
          <TrendingUp className="mr-2" size={16} />
          Take Skills Assessment
        </Button>
      </CardContent>
    </Card>
  );
}
