import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { CloudUpload, Check, AlertCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function FileUpload() {
  const [uploadProgress, setUploadProgress] = useState(0);
  const [analysisComplete, setAnalysisComplete] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("resume", file);

      const response = await fetch("/api/resume/upload", {
        method: "POST",
        body: formData,
        credentials: "include",
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Upload failed");
      }

      return response.json();
    },
    onSuccess: (data) => {
      setAnalysisComplete(true);
      toast({
        title: "Resume analyzed successfully!",
        description: `Your resume scored ${data.analysis.overallScore}/100`,
      });
      // Invalidate related queries to refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/resume/analysis"] });
      queryClient.invalidateQueries({ queryKey: ["/api/skills"] });
      queryClient.invalidateQueries({ queryKey: ["/api/recommendations"] });
    },
    onError: (error) => {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
      setUploadProgress(0);
    },
  });

  const onDrop = useCallback(
    (acceptedFiles: File[]) => {
      const file = acceptedFiles[0];
      if (!file) return;

      // Validate file size (10MB)
      if (file.size > 10 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "Please upload a file smaller than 10MB",
          variant: "destructive",
        });
        return;
      }

      setUploadProgress(0);
      setAnalysisComplete(false);

      // Simulate upload progress
      const progressInterval = setInterval(() => {
        setUploadProgress((prev) => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + Math.random() * 10;
        });
      }, 200);

      uploadMutation.mutate(file);
    },
    [uploadMutation, toast]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'text/plain': ['.txt'],
    },
    multiple: false,
  });

  // Complete progress when mutation succeeds
  if (uploadMutation.isSuccess && uploadProgress < 100) {
    setTimeout(() => setUploadProgress(100), 500);
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Resume Analysis</CardTitle>
          <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80">
            Re-analyze
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div
          {...getRootProps()}
          className={`border-2 border-dashed rounded-xl p-8 text-center transition-colors cursor-pointer ${
            isDragActive
              ? "border-primary bg-primary/5"
              : uploadMutation.isSuccess
              ? "border-success bg-success/5"
              : "border-gray-300 hover:border-primary"
          }`}
        >
          <input {...getInputProps()} />
          
          {uploadMutation.isSuccess ? (
            <>
              <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="text-success" size={32} />
              </div>
              <h4 className="text-lg font-medium text-gray-900 mb-2">Resume Uploaded Successfully</h4>
              <p className="text-gray-600 mb-4">AI analysis completed</p>
              <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
                <div 
                  className="bg-success h-2 rounded-full transition-all duration-500" 
                  style={{ width: "100%" }}
                />
              </div>
            </>
          ) : uploadMutation.isPending ? (
            <>
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <CloudUpload className="text-primary animate-pulse" size={32} />
              </div>
              <h4 className="text-lg font-medium text-gray-900 mb-2">Analyzing Resume...</h4>
              <p className="text-gray-600 mb-4">AI analysis in progress</p>
              <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
                <div 
                  className="bg-primary h-2 rounded-full transition-all duration-300" 
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
              <p className="text-sm text-gray-500">{Math.round(uploadProgress)}% complete</p>
            </>
          ) : (
            <>
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <CloudUpload className="text-primary" size={32} />
              </div>
              <h4 className="text-lg font-medium text-gray-900 mb-2">Upload Your Resume</h4>
              <p className="text-gray-600 mb-4">
                {isDragActive 
                  ? "Drop your resume here" 
                  : "Drag and drop your resume here, or click to browse"}
              </p>
              <Button className="bg-primary hover:bg-primary/90">
                Choose File
              </Button>
              <p className="text-sm text-gray-500 mt-2">Supports PDF, DOC, DOCX (Max 10MB)</p>
            </>
          )}
        </div>

        {uploadMutation.isError && (
          <div className="mt-4 p-4 bg-destructive/10 rounded-lg border border-destructive/20">
            <div className="flex items-center text-destructive">
              <AlertCircle size={16} className="mr-2" />
              <span className="text-sm font-medium">Upload Error</span>
            </div>
            <p className="text-sm text-destructive/80 mt-1">
              {uploadMutation.error?.message || "Something went wrong"}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
