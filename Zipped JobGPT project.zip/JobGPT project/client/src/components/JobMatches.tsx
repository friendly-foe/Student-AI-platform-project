import { useQuery } from "@tanstack/react-query";
import { Briefcase, MapPin, DollarSign, ExternalLink } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

export default function JobMatches() {
  const { data: jobMatches = [], isLoading } = useQuery({
    queryKey: ["/api/job-matches"],
  });

  const getMatchBadgeVariant = (score: number) => {
    if (score >= 90) return "default";
    if (score >= 80) return "secondary";
    if (score >= 70) return "outline";
    return "outline";
  };

  const getMatchBadgeColor = (score: number) => {
    if (score >= 90) return "bg-success/10 text-success border-success/20";
    if (score >= 80) return "bg-warning/10 text-warning border-warning/20";
    if (score >= 70) return "bg-primary/10 text-primary border-primary/20";
    return "bg-gray-100 text-gray-600 border-gray-200";
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-32" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="border border-gray-200 rounded-lg p-4">
                <Skeleton className="h-4 w-48 mb-2" />
                <Skeleton className="h-3 w-32 mb-2" />
                <Skeleton className="h-3 w-40 mb-3" />
                <div className="flex justify-between">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-6 w-16" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            <Briefcase className="mr-2" size={20} />
            Top Job Matches
          </CardTitle>
          <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80">
            View All
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {jobMatches.length === 0 ? (
          <div className="text-center py-8">
            <Briefcase className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No Job Matches</h3>
            <p className="text-gray-600 text-sm mb-4">Upload a resume and update your skills to find job matches.</p>
            <Button size="sm">Upload Resume</Button>
          </div>
        ) : (
          <div className="space-y-4">
            {jobMatches.slice(0, 3).map((match: any) => (
              <div
                key={match.id}
                className="border border-gray-200 rounded-lg p-4 hover:border-primary/50 transition-colors cursor-pointer group"
              >
                <div className="flex items-start justify-between mb-2">
                  <h4 className="font-medium text-gray-900 text-sm group-hover:text-primary transition-colors">
                    {match.job.title}
                  </h4>
                  <Badge className={`text-xs ${getMatchBadgeColor(match.matchScore)}`}>
                    {match.matchScore}% match
                  </Badge>
                </div>
                
                <p className="text-sm text-gray-600 mb-1">{match.job.company}</p>
                
                <div className="flex items-center text-xs text-gray-500 mb-2">
                  <MapPin className="mr-1" size={12} />
                  <span>{match.job.location}</span>
                  {match.job.remote && (
                    <>
                      <span className="mx-1">•</span>
                      <span>Remote</span>
                    </>
                  )}
                </div>

                {match.job.salary && (
                  <div className="flex items-center text-xs text-gray-500 mb-3">
                    <DollarSign className="mr-1" size={12} />
                    <span>{match.job.salary}</span>
                  </div>
                )}

                {/* Match reasons */}
                {match.reasons && match.reasons.length > 0 && (
                  <div className="mb-3">
                    <p className="text-xs text-gray-600 mb-1">Why this matches:</p>
                    <p className="text-xs text-gray-500">{match.reasons[0]}</p>
                  </div>
                )}

                <div className="flex items-center justify-between">
                  <div className="flex flex-wrap gap-1">
                    {match.job.requirements?.slice(0, 2).map((req: string, index: number) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {req}
                      </Badge>
                    ))}
                    {match.job.requirements?.length > 2 && (
                      <Badge variant="outline" className="text-xs">
                        +{match.job.requirements.length - 2} more
                      </Badge>
                    )}
                  </div>
                  <Button 
                    size="sm" 
                    variant="ghost"
                    className="text-primary hover:text-primary/80 text-xs p-1 h-auto"
                  >
                    Apply Now
                    <ExternalLink className="ml-1" size={12} />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        {jobMatches.length > 3 && (
          <Button variant="outline" className="w-full mt-4" size="sm">
            View {jobMatches.length - 3} More Matches
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
